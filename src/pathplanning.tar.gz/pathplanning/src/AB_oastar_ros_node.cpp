// AB_oastar_ros_node.cpp
// 改进A*算法的B1机器人兼容版本
#include "pathplanning/OAstar.h"
#include <ros/ros.h>
#include <nav_msgs/OccupancyGrid.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <nav_msgs/Path.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include <std_srvs/SetBool.h>

namespace pathplanning {

class ABOAStarROSNode {
private:
    ros::NodeHandle nh_;
    ros::NodeHandle private_nh_;
    
    // 发布器和订阅器 - 适配B1机器人
    ros::Subscriber map_sub_;      // 订阅B1的/map话题
    ros::Subscriber start_sub_;
    ros::Subscriber goal_sub_;
    ros::Publisher astar_path_pub_;
    ros::Publisher global_path_pub_;
    ros::Publisher marker_pub_;
    
    // 服务
    ros::ServiceServer enable_planning_service_;
    
    // 状态标志
    bool map_initialized_;
    bool has_start_;
    bool has_goal_;
    bool planning_enabled_;
    
    // 当前起点和目标点
    geometry_msgs::PoseStamped current_start_;
    geometry_msgs::PoseStamped current_goal_;
    
    // 路径规划器
    OAstar astar_;
    
    // 地图参数
    double resolution_;
    double origin_x_;
    double origin_y_;
    int width_;
    int height_;
    
    // TF监听器
    tf2_ros::Buffer tf_buffer_;
    tf2_ros::TransformListener tf_listener_;
    
    // 上次规划时间
    ros::Time last_planning_time_;

public:
    ABOAStarROSNode():
        private_nh_("~"),
        map_initialized_(false),
        has_start_(false),
        has_goal_(false),
        planning_enabled_(true),
        resolution_(0.05),
        origin_x_(-5.0),
        origin_y_(-5.0),
        width_(200),
        height_(200),
        tf_listener_(tf_buffer_) {
        
        ROS_INFO("==========================================");
        ROS_INFO("    AB 改进A* ROS节点初始化 (B1机器人兼容版)");
        ROS_INFO("==========================================");
        
        // 初始化发布器和订阅器
        initializeSubscribers();
        initializePublishers();
        initializeServices();
        
        // 初始化参数
        initializeParameters();
        
        ROS_INFO("AB改进A*节点初始化完成");
        ROS_INFO("等待地图、起点和目标点...");
        ROS_INFO("==========================================");
    }
    
    ~ABOAStarROSNode() {
        ROS_INFO("AB改进A*节点关闭");
    }
    
    void run() {
        ros::spin();
    }

private:
    void initializeParameters() {
        // 加载A*算法参数
        OAstarConfig config;
        
        // 从参数服务器获取参数
        private_nh_.param<double>("heuristic_weight", config.heuristic_weight, 1.0);
        private_nh_.param<int>("inflate_radius", config.inflate_radius, 5);
        private_nh_.param<double>("safety_margin", config.safety_margin, 0.3);
        private_nh_.param<double>("obstacle_clearance", config.obstacle_clearance, 0.3);
        private_nh_.param<double>("turn_penalty_weight", config.turn_penalty_weight, 0.3);
        private_nh_.param<bool>("euclidean", config.euclidean, true);
        private_nh_.param<bool>("allow_outside_map", config.allow_outside_map, false);
        private_nh_.param<int>("max_iterations", config.max_iterations, 20000);
        
        // 平滑参数
        private_nh_.param<bool>("enable_path_smoothing", config.enable_path_smoothing, true);
        private_nh_.param<bool>("enable_bspline_smoothing", config.enable_bspline_smoothing, true);
        private_nh_.param<bool>("enable_path_resample", config.enable_path_resample, true);
        
        // 设置规划器配置
        astar_.setConfig(config);
        
        // B1特定设置：忽略动态障碍物，锁定原始地图
        astar_.setIgnoreDynamicObstacles(true);
        astar_.setLockOriginalMap(true);
        
        ROS_INFO("A*参数加载完成");
        ROS_INFO("启发式权重: %.1f", config.heuristic_weight);
        ROS_INFO("膨胀半径: %d", config.inflate_radius);
        ROS_INFO("安全边界: %.1f", config.safety_margin);
    }
    
    void initializeSubscribers() {
        // 订阅B1机器人的地图话题
        map_sub_ = nh_.subscribe<nav_msgs::OccupancyGrid>(
            "/map", 1, &ABOAStarROSNode::mapCallback, this);
        
        // 订阅起点（从Rviz的2D Pose Estimate）
        start_sub_ = nh_.subscribe<geometry_msgs::PoseWithCovarianceStamped>(
            "/initialpose", 1, &ABOAStarROSNode::startCallback, this);
        
        // 订阅目标点（从Rviz的2D Nav Goal）
        goal_sub_ = nh_.subscribe<geometry_msgs::PoseStamped>(
            "/move_base_simple/goal", 1, &ABOAStarROSNode::goalCallback, this);
        
        ROS_INFO("订阅器初始化完成:");
        ROS_INFO("  /map (地图)");
        ROS_INFO("  /initialpose (起点)");
        ROS_INFO("  /move_base_simple/goal (目标点)");
    }
    
    void initializePublishers() {
        // 发布A*规划的全局路径
        astar_path_pub_ = nh_.advertise<nav_msgs::Path>("/astar_global_path", 1, true);
        
        // 发布可视化标记
        marker_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/astar_markers", 1);
        
        ROS_INFO("发布器初始化完成:");
        ROS_INFO("  /astar_global_path (A*全局路径)");
        ROS_INFO("  /astar_markers (可视化标记)");
    }
    
    void initializeServices() {
        // 启用/禁用规划服务
        enable_planning_service_ = private_nh_.advertiseService(
            "enable_planning", 
            &ABOAStarROSNode::enablePlanningCallback, 
            this);
        
        ROS_INFO("服务初始化完成:");
        ROS_INFO("  /ab_oastar/enable_planning");
    }
    
    void mapCallback(const nav_msgs::OccupancyGrid::ConstPtr& msg) {
        if (!msg || msg->info.width == 0) {
            ROS_WARN("收到空地图");
            return;
        }
        
        ROS_INFO("=== 地图回调 ===");
        ROS_INFO("地图尺寸: %dx%d, 分辨率: %.3f m/像素", 
                 msg->info.width, msg->info.height, msg->info.resolution);
        ROS_INFO("地图原点: (%.2f, %.2f)", 
                 msg->info.origin.position.x, msg->info.origin.position.y);
        
        // 更新地图参数
        resolution_ = msg->info.resolution;
        origin_x_ = msg->info.origin.position.x;
        origin_y_ = msg->info.origin.position.y;
        width_ = msg->info.width;
        height_ = msg->info.height;
        
        // 更新A*规划器地图
        astar_.updateMap(msg);
        map_initialized_ = true;
        
        ROS_INFO("地图初始化完成，准备进行路径规划");
        
        // 如果已经有起点和目标点，立即尝试规划
        if (has_start_ && has_goal_) {
            ROS_INFO("收到地图时已有起点和目标点，触发规划");
            triggerPlanning();
        }
    }
    
    void startCallback(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& msg) {
        ROS_INFO("=== 起点回调 ===");
        ROS_INFO("起点: (%.2f, %.2f)", 
                 msg->pose.pose.position.x, msg->pose.pose.position.y);
        
        // 保存起点
        current_start_.header = msg->header;
        current_start_.pose = msg->pose.pose;
        has_start_ = true;
        
        // 设置A*规划器起点
        astar_.setStartPoint(msg);
        
        // 检查是否满足规划条件
        if (map_initialized_) {
            if (has_goal_) {
                ROS_INFO("起点已设置，地图和目标点已就绪，触发规划");
                triggerPlanning();
            } else {
                ROS_INFO("起点已设置，等待目标点...");
            }
        } else {
            ROS_INFO("起点已设置，等待地图...");
        }
        
        // 发布可视化标记
        publishMarkers();
    }
    
    void goalCallback(const geometry_msgs::PoseStamped::ConstPtr& msg) {
        ROS_INFO("=== 目标点回调 ===");
        ROS_INFO("目标点: (%.2f, %.2f)", 
                 msg->pose.position.x, msg->pose.position.y);
        ROS_INFO("坐标系: %s", msg->header.frame_id.c_str());
        
        // 保存目标点
        current_goal_ = *msg;
        has_goal_ = true;
        
        // 设置A*规划器目标点
        astar_.setTargetPoint(msg);
        
        // 检查是否满足规划条件
        if (map_initialized_) {
            if (has_start_) {
                ROS_INFO("目标点已设置，地图和起点已就绪，触发规划");
                triggerPlanning();
            } else {
                ROS_INFO("目标点已设置，等待起点...");
            }
        } else {
            ROS_INFO("目标点已设置，等待地图...");
        }
        
        // 发布可视化标记
        publishMarkers();
    }
    
    bool enablePlanningCallback(std_srvs::SetBool::Request& req,
                                std_srvs::SetBool::Response& res) {
        planning_enabled_ = req.data;
        res.success = true;
        res.message = planning_enabled_ ? 
            "路径规划已启用" : "路径规划已禁用";
        
        ROS_INFO("%s", res.message.c_str());
        
        // 如果已启用且满足条件，重新规划
        if (planning_enabled_ && map_initialized_ && has_start_ && has_goal_) {
            triggerPlanning();
        }
        
        return true;
    }
    
    void triggerPlanning() {
        if (!planning_enabled_) {
            ROS_INFO("路径规划被禁用，跳过规划");
            return;
        }
        
        if (!map_initialized_ || !has_start_ || !has_goal_) {
            ROS_WARN("无法触发规划: 地图=%d, 起点=%d, 目标点=%d",
                     map_initialized_, has_start_, has_goal_);
            return;
        }
        
        // 检查规划间隔
        ros::Time now = ros::Time::now();
        if ((now - last_planning_time_).toSec() < 0.1) {
            ROS_DEBUG("跳过规划，频率过高");
            return;
        }
        
        last_planning_time_ = now;
        
        ROS_INFO("=== 触发路径规划 ===");
        ROS_INFO("起点: (%.2f, %.2f)", 
                 current_start_.pose.position.x, current_start_.pose.position.y);
        ROS_INFO("目标: (%.2f, %.2f)", 
                 current_goal_.pose.position.x, current_goal_.pose.position.y);
        
        try {
            // 执行A*路径规划
            std::vector<cv::Point> path_points;
            ROS_INFO("开始A*路径规划...");
            
            if (astar_.pathPlanning(path_points)) {
                ROS_INFO("A*规划成功，找到 %zu 个路径点", path_points.size());
                publishPath(path_points);
            } else {
                ROS_WARN("A*规划失败，使用备用直线路径");
                generateStraightPath(path_points);
                publishPath(path_points);
            }
        } catch (const std::exception& e) {
            ROS_ERROR("规划过程中发生异常: %s", e.what());
            std::vector<cv::Point> path_points;
            generateStraightPath(path_points);
            publishPath(path_points);
        }
    }
    
    void generateStraightPath(std::vector<cv::Point>& path_points) {
        path_points.clear();
        
        // 将起点和终点转换为地图坐标
        cv::Point start_pt = astar_.worldToMap(
            current_start_.pose.position.x, 
            current_start_.pose.position.y
        );
        cv::Point goal_pt = astar_.worldToMap(
            current_goal_.pose.position.x, 
            current_goal_.pose.position.y
        );
        
        ROS_INFO("生成直线路径从 (%d,%d) 到 (%d,%d)", 
                 start_pt.x, start_pt.y, goal_pt.x, goal_pt.y);
        
        // Bresenham直线算法
        int x1 = start_pt.x, y1 = start_pt.y;
        int x2 = goal_pt.x, y2 = goal_pt.y;
        
        int dx = abs(x2 - x1);
        int dy = abs(y2 - y1);
        int sx = (x1 < x2) ? 1 : -1;
        int sy = (y1 < y2) ? 1 : -1;
        int err = dx - dy;
        
        while (true) {
            path_points.push_back(cv::Point(x1, y1));
            
            if (x1 == x2 && y1 == y2) {
                break;
            }
            
            int e2 = 2 * err;
            if (e2 > -dy) {
                err -= dy;
                x1 += sx;
            }
            if (e2 < dx) {
                err += dx;
                y1 += sy;
            }
        }
        
        ROS_INFO("生成直线路径，共 %zu 个点", path_points.size());
    }
    
    void publishPath(const std::vector<cv::Point>& path_points) {
        if (path_points.empty()) {
            ROS_WARN("没有路径点可发布");
            return;
        }
        
        // 创建路径消息
        nav_msgs::Path path_msg = astar_.convertToWorldPath(path_points);
        
        // 设置时间戳和坐标系
        path_msg.header.stamp = ros::Time::now();
        path_msg.header.frame_id = "map";
        
        // 发布到路径话题
        astar_path_pub_.publish(path_msg);
        ROS_INFO("发布路径到 /astar_global_path，共 %zu 个点", path_msg.poses.size());
        
        // 发布可视化标记
        publishPathMarkers(path_msg);
    }
    
    void publishPathMarkers(const nav_msgs::Path& path) {
        visualization_msgs::MarkerArray marker_array;
        
        // 清理之前的路径标记
        visualization_msgs::Marker clear_marker;
        clear_marker.header.frame_id = "map";
        clear_marker.header.stamp = ros::Time::now();
        clear_marker.ns = "ab_astar_path";
        clear_marker.id = 0;
        clear_marker.action = visualization_msgs::Marker::DELETEALL;
        marker_array.markers.push_back(clear_marker);
        
        // 发布路径线
        if (path.poses.size() > 1) {
            visualization_msgs::Marker line_marker;
            line_marker.header.frame_id = "map";
            line_marker.header.stamp = ros::Time::now();
            line_marker.ns = "ab_astar_path";
            line_marker.id = 1;
            line_marker.type = visualization_msgs::Marker::LINE_STRIP;
            line_marker.action = visualization_msgs::Marker::ADD;
            line_marker.scale.x = 0.1;  // 线宽
            line_marker.color.r = 0.0;
            line_marker.color.g = 1.0;
            line_marker.color.b = 0.0;
            line_marker.color.a = 1.0;
            line_marker.lifetime = ros::Duration();
            
            for (const auto& pose : path.poses) {
                geometry_msgs::Point p;
                p.x = pose.pose.position.x;
                p.y = pose.pose.position.y;
                p.z = 0.0;
                line_marker.points.push_back(p);
            }
            
            marker_array.markers.push_back(line_marker);
        }
        
        marker_pub_.publish(marker_array);
    }
    
    void publishMarkers() {
        visualization_msgs::MarkerArray marker_array;
        
        // 清理之前的标记
        visualization_msgs::Marker clear_marker;
        clear_marker.header.frame_id = "map";
        clear_marker.header.stamp = ros::Time::now();
        clear_marker.ns = "ab_astar";
        clear_marker.id = 0;
        clear_marker.action = visualization_msgs::Marker::DELETEALL;
        marker_array.markers.push_back(clear_marker);
        
        // 发布起点标记
        if (has_start_) {
            visualization_msgs::Marker start_marker;
            start_marker.header.frame_id = "map";
            start_marker.header.stamp = ros::Time::now();
            start_marker.ns = "ab_astar";
            start_marker.id = 1;
            start_marker.type = visualization_msgs::Marker::SPHERE;
            start_marker.action = visualization_msgs::Marker::ADD;
            start_marker.pose = current_start_.pose;
            start_marker.pose.orientation.w = 1.0;
            start_marker.scale.x = 0.3;
            start_marker.scale.y = 0.3;
            start_marker.scale.z = 0.3;
            start_marker.color.r = 0.0;
            start_marker.color.g = 1.0;
            start_marker.color.b = 0.0;
            start_marker.color.a = 1.0;
            start_marker.lifetime = ros::Duration();
            marker_array.markers.push_back(start_marker);
        }
        
        // 发布目标点标记
        if (has_goal_) {
            visualization_msgs::Marker goal_marker;
            goal_marker.header.frame_id = "map";
            goal_marker.header.stamp = ros::Time::now();
            goal_marker.ns = "ab_astar";
            goal_marker.id = 2;
            goal_marker.type = visualization_msgs::Marker::SPHERE;
            goal_marker.action = visualization_msgs::Marker::ADD;
            goal_marker.pose = current_goal_.pose;
            goal_marker.pose.orientation.w = 1.0;
            goal_marker.scale.x = 0.3;
            goal_marker.scale.y = 0.3;
            goal_marker.scale.z = 0.3;
            goal_marker.color.r = 1.0;
            goal_marker.color.g = 0.0;
            goal_marker.color.b = 0.0;
            goal_marker.color.a = 1.0;
            goal_marker.lifetime = ros::Duration();
            marker_array.markers.push_back(goal_marker);
        }
        
        marker_pub_.publish(marker_array);
    }
};

}  // namespace pathplanning

int main(int argc, char** argv) {
    ros::init(argc, argv, "ab_oastar_ros_node");
    
    try {
        ROS_INFO("启动AB改进A* ROS节点...");
        pathplanning::ABOAStarROSNode node;
        node.run();
    } catch (const std::exception& e) {
        ROS_ERROR("AB改进A* ROS节点异常: %s", e.what());
        return 1;
    }
    
    return 0;
}