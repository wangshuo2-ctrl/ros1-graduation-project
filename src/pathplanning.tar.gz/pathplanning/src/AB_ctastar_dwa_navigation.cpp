// AB_ctastar_dwa_navigation.cpp
// 改进A*+传统DWA算法的B1机器人兼容版本
#include "pathplanning/Astar.h"
#include "pathplanning/ctDWAPlanner.h"
#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <nav_msgs/OccupancyGrid.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/String.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include <angles/angles.h>
#include <tf/tf.h>
#include <opencv2/core/core.hpp>
#include <vector>
#include <queue>
#include <cmath>
#include <algorithm>
#include <mutex>
#include <memory>
#include <iostream>
#include <chrono>

using namespace pathplanning;

namespace quaternion_utils {
    double getYawFromQuaternion(const geometry_msgs::Quaternion& quat) {
        tf::Quaternion tf_quat;
        tf::quaternionMsgToTF(quat, tf_quat);
        double roll, pitch, yaw;
        tf::Matrix3x3(tf_quat).getRPY(roll, pitch, yaw);
        return yaw;
    }
    
    geometry_msgs::Quaternion createQuaternionFromYaw(double yaw) {
        tf::Quaternion tf_quat = tf::createQuaternionFromYaw(yaw);
        geometry_msgs::Quaternion quat;
        tf::quaternionTFToMsg(tf_quat, quat);
        return quat;
    }
}

class ABCTAStarDWANavigation {
private:
    ros::NodeHandle nh_;
    ros::NodeHandle private_nh_;
    
    // 规划器
    std::shared_ptr<Astar> astar_planner_;
    std::shared_ptr<ctDWAPlanner> dwa_planner_;  // 传统DWA规划器
    
    // 订阅器
    ros::Subscriber map_sub_;
    ros::Subscriber start_sub_;
    ros::Subscriber goal_sub_;
    ros::Subscriber odom_sub_;
    
    // 发布器
    ros::Publisher global_path_pub_;
    ros::Publisher local_path_pub_;
    ros::Publisher cmd_vel_pub_;
    ros::Publisher status_pub_;
    ros::Publisher marker_pub_;
    ros::Publisher astar_path_pub_;
    
    // 导航状态
    enum NavigationState {
        WAITING_FOR_MAP = 0,
        WAITING_FOR_START = 1,
        WAITING_FOR_GOAL = 2,
        BOTH_POINTS_SET = 3,
        PLANNING = 4,
        EXECUTING = 5,
        GOAL_REACHED = 6,
        FAILED = 7
    };
    
    NavigationState current_state_;
    
    // 数据
    nav_msgs::OccupancyGrid current_map_;
    geometry_msgs::PoseStamped robot_pose_;
    geometry_msgs::Twist robot_velocity_;
    std::vector<geometry_msgs::PoseStamped> global_path_;
    std::vector<geometry_msgs::PoseStamped> local_path_;
    geometry_msgs::PoseStamped current_goal_;
    geometry_msgs::PoseWithCovarianceStamped current_start_;
    
    // 配置参数
    struct Config {
        double control_frequency = 10.0;
        double goal_tolerance = 0.15;
        double min_replan_interval = 0.1;
        bool enable_replanning = true;
        bool use_tf_for_pose = false;
        double max_planning_time = 5.0;
        std::string global_path_topic = "/ab_ct_global_plan";
        std::string local_path_topic = "/ab_ct_local_path";
        std::string astar_path_topic = "/ab_ct_astar_path";
    } config_;
    
    // 状态标志
    bool start_point_set_;
    bool target_point_set_;
    bool map_ready_;
    bool robot_pose_valid_;
    bool use_simulated_odom_;
    bool abort_current_planning_;
    
    // 时间
    ros::Time last_planning_time_;
    ros::Time last_control_time_;
    
    // 计数器
    int planning_attempts_;
    int navigation_counter_;
    int navigation_id_;
    
    // 互斥锁
    std::mutex data_mutex_;

public:
    ABCTAStarDWANavigation() :
        private_nh_("~"),
        current_state_(WAITING_FOR_MAP),
        start_point_set_(false),
        target_point_set_(false),
        map_ready_(false),
        robot_pose_valid_(false),
        use_simulated_odom_(false),  // B1机器人使用真实里程计
        abort_current_planning_(false),
        planning_attempts_(0),
        navigation_counter_(0),
        navigation_id_(0) {
        
        ROS_INFO("==========================================");
        ROS_INFO("  AB 改进A*+传统DWA导航系统 (B1机器人版)");
        ROS_INFO("==========================================");
        
        try {
            initializeSafe();
            ROS_INFO("导航系统初始化成功");
        } catch (const std::exception& e) {
            ROS_FATAL("导航系统初始化失败: %s", e.what());
            throw;
        }
    }
    
    void run() {
        ROS_INFO("启动导航系统主循环，频率: %.1f Hz", config_.control_frequency);
        ros::Rate rate(config_.control_frequency);
        
        while (ros::ok()) {
            processNavigation();
            publishStatus();
            ros::spinOnce();
            rate.sleep();
        }
        
        ROS_INFO("导航系统关闭");
    }

private:
    void initializeSafe() {
        try {
            initializeParameters();
            initializePlanners();
            initializeROS();
            
            last_planning_time_ = ros::Time::now();
            last_control_time_ = ros::Time::now();
            
            ROS_INFO("所有组件初始化成功");
        } catch (const std::exception& e) {
            ROS_FATAL("初始化失败: %s", e.what());
            throw;
        }
    }
    
    void initializeParameters() {
        // 从参数服务器加载配置
        private_nh_.param("control_frequency", config_.control_frequency, 10.0);
        private_nh_.param("goal_tolerance", config_.goal_tolerance, 0.15);
        private_nh_.param("min_replan_interval", config_.min_replan_interval, 0.1);
        private_nh_.param("enable_replanning", config_.enable_replanning, true);
        private_nh_.param("use_tf_for_pose", config_.use_tf_for_pose, false);
        private_nh_.param("max_planning_time", config_.max_planning_time, 5.0);
        private_nh_.param("global_path_topic", config_.global_path_topic, std::string("/ab_ct_global_plan"));
        private_nh_.param("local_path_topic", config_.local_path_topic, std::string("/ab_ct_local_path"));
        private_nh_.param("astar_path_topic", config_.astar_path_topic, std::string("/ab_ct_astar_path"));
        
        // B1机器人设置：使用真实里程计
        private_nh_.param("use_simulated_odom", use_simulated_odom_, false);
        
        ROS_INFO("导航参数:");
        ROS_INFO("  控制频率: %.1f Hz", config_.control_frequency);
        ROS_INFO("  目标容差: %.3f m", config_.goal_tolerance);
        ROS_INFO("  最小重规划间隔: %.3f s", config_.min_replan_interval);
        ROS_INFO("  使用模拟里程计: %s", use_simulated_odom_ ? "是" : "否");
    }
    
    void initializePlanners() {
        ROS_INFO("初始化A*规划器...");
        try {
            astar_planner_ = std::make_shared<Astar>();
            
            // 加载A*参数
            AstarConfig astar_config;
            private_nh_.param("heuristic_weight", astar_config.heuristic_weight, 1.0);
            private_nh_.param("inflate_radius", astar_config.inflate_radius, 5);
            private_nh_.param("safety_margin", astar_config.safety_margin, 0.3);
            private_nh_.param("max_iterations", astar_config.max_iterations, 20000);
            private_nh_.param("enable_path_smoothing", astar_config.enable_path_smoothing, true);
            private_nh_.param("enable_bspline_smoothing", astar_config.enable_bspline_smoothing, true);
            
            astar_planner_->initAstar(astar_config);
            ROS_INFO("A*规划器初始化成功");
        } catch (const std::exception& e) {
            ROS_FATAL("A*规划器初始化失败: %s", e.what());
            throw;
        }
        
        ROS_INFO("初始化传统DWA规划器...");
        try {
            dwa_planner_ = std::make_shared<ctDWAPlanner>();
            
            // 加载传统DWA参数
            ctDWAParams dwa_params;
            private_nh_.param("max_vel_x", dwa_params.max_vel_x, 0.22);
            private_nh_.param("min_vel_x", dwa_params.min_vel_x, 0.0);
            private_nh_.param("max_vel_x_backwards", dwa_params.max_vel_x_backwards, -0.1);
            private_nh_.param("max_vel_theta", dwa_params.max_vel_theta, 2.75);
            private_nh_.param("min_vel_theta", dwa_params.min_vel_theta, -2.75);
            private_nh_.param("acc_lim_x", dwa_params.acc_lim_x, 2.5);
            private_nh_.param("acc_lim_theta", dwa_params.acc_lim_theta, 3.2);
            private_nh_.param("vx_samples", dwa_params.vx_samples, 20);
            private_nh_.param("vth_samples", dwa_params.vth_samples, 40);
            private_nh_.param("sim_time", dwa_params.sim_time, 1.5);
            private_nh_.param("dt", dwa_params.dt, 0.1);
            private_nh_.param("xy_goal_tolerance", dwa_params.xy_goal_tolerance, 0.15);
            private_nh_.param("yaw_goal_tolerance", dwa_params.yaw_goal_tolerance, 0.17);
            private_nh_.param("goal_distance_bias", dwa_params.goal_distance_bias, 20.0);
            private_nh_.param("path_distance_bias", dwa_params.path_distance_bias, 32.0);
            private_nh_.param("robot_radius", dwa_params.robot_radius, 0.25);
            private_nh_.param("obstacle_cost_bias", dwa_params.obstacle_cost_bias, 1.0);
            private_nh_.param("occdist_scale", dwa_params.occdist_scale, 0.02);
            private_nh_.param("obstacle_cutoff_dist", dwa_params.obstacle_cutoff_dist, 2.5);
            private_nh_.param("controller_frequency", dwa_params.controller_frequency, 10.0);
            private_nh_.param("sim_granularity", dwa_params.sim_granularity, 0.025);
            private_nh_.param("obstacle_threshold", dwa_params.obstacle_threshold, 60);
            
            dwa_planner_->setParams(dwa_params);
            dwa_planner_->initialize();
            ROS_INFO("传统DWA规划器初始化成功");
        } catch (const std::exception& e) {
            ROS_FATAL("传统DWA规划器初始化失败: %s", e.what());
            throw;
        }
    }
    
    // 接上文的 AB_ctastar_dwa_navigation.cpp
void initializeROS() {
    // 订阅器
    map_sub_ = nh_.subscribe<nav_msgs::OccupancyGrid>("/map", 1, 
        &ABCTAStarDWANavigation::mapCallback, this);
    start_sub_ = nh_.subscribe<geometry_msgs::PoseWithCovarianceStamped>("/initialpose", 1,
        &ABCTAStarDWANavigation::startCallback, this);
    goal_sub_ = nh_.subscribe<geometry_msgs::PoseStamped>("/move_base_simple/goal", 1,
        &ABCTAStarDWANavigation::goalCallback, this);
    odom_sub_ = nh_.subscribe<nav_msgs::Odometry>("/odom", 1,
        &ABCTAStarDWANavigation::odomCallback, this);
    
    // 发布器
    global_path_pub_ = nh_.advertise<nav_msgs::Path>(config_.global_path_topic, 1, true);
    local_path_pub_ = nh_.advertise<nav_msgs::Path>(config_.local_path_topic, 1, true);
    astar_path_pub_ = nh_.advertise<nav_msgs::Path>(config_.astar_path_topic, 1, true);
    cmd_vel_pub_ = nh_.advertise<geometry_msgs::Twist>("/ab_ct_cmd_vel", 1);  // 传统DWA控制话题
    status_pub_ = nh_.advertise<std_msgs::String>("/ab_ct_navigation_status", 1, true);
    marker_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/ab_ct_navigation_markers", 1, true);
    
    ROS_INFO("ROS组件初始化完成");
}

void mapCallback(const nav_msgs::OccupancyGrid::ConstPtr& grid) {
    std::lock_guard<std::mutex> lock(data_mutex_);
    
    if (!grid || grid->info.width == 0 || grid->info.height == 0) {
        return;
    }
    
    current_map_ = *grid;
    
    if (astar_planner_) astar_planner_->updateMap(grid);
    if (dwa_planner_) dwa_planner_->updateCostMap(grid);
    
    if (!map_ready_) {
        map_ready_ = true;
        if (current_state_ == WAITING_FOR_MAP) {
            current_state_ = WAITING_FOR_START;
        }
    }
}

void startCallback(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& msg) {
    std::lock_guard<std::mutex> lock(data_mutex_);
    
    if (!msg) return;
    
    ROS_INFO("=== 起点设置 ===");
    ROS_INFO("起点: (%.3f, %.3f)", 
             msg->pose.pose.position.x, msg->pose.pose.position.y);
    
    current_start_ = *msg;
    start_point_set_ = true;
    
    if (astar_planner_) astar_planner_->setStartPoint(msg);
    
    // 如果使用模拟里程计，更新机器人位姿
    if (use_simulated_odom_) {
        robot_pose_.header = msg->header;
        robot_pose_.pose = msg->pose.pose;
        robot_pose_valid_ = true;
        robot_velocity_.linear.x = 0.0;
        robot_velocity_.angular.z = 0.0;
    }
    
    updateState();
}

void goalCallback(const geometry_msgs::PoseStamped::ConstPtr& msg) {
    std::lock_guard<std::mutex> lock(data_mutex_);
    
    if (!msg) return;
    
    ROS_INFO("=== 目标点设置 ===");
    ROS_INFO("目标点: (%.3f, %.3f)", 
             msg->pose.position.x, msg->pose.position.y);
    
    current_goal_ = *msg;
    target_point_set_ = true;
    
    if (astar_planner_) astar_planner_->setTargetPoint(msg);
    
    updateState();
}

void odomCallback(const nav_msgs::Odometry::ConstPtr& msg) {
    if (!use_simulated_odom_) {
        robot_pose_.header = msg->header;
        robot_pose_.pose = msg->pose.pose;
        robot_velocity_ = msg->twist.twist;
        robot_pose_valid_ = true;
    }
}

void updateState() {
    if (!map_ready_) {
        current_state_ = WAITING_FOR_MAP;
    } else if (!start_point_set_) {
        current_state_ = WAITING_FOR_START;
    } else if (!target_point_set_) {
        current_state_ = WAITING_FOR_GOAL;
    } else {
        current_state_ = BOTH_POINTS_SET;
    }
}

void processNavigation() {
    std::lock_guard<std::mutex> lock(data_mutex_);
    
    switch (current_state_) {
        case WAITING_FOR_MAP:
            handleWaitingForMap();
            break;
        case WAITING_FOR_START:
            handleWaitingForStart();
            break;
        case WAITING_FOR_GOAL:
            handleWaitingForGoal();
            break;
        case BOTH_POINTS_SET:
            handleBothPointsSet();
            break;
        case PLANNING:
            executePlanning();
            break;
        case EXECUTING:
            executeControl();
            break;
        case GOAL_REACHED:
            handleGoalReached();
            break;
        case FAILED:
            handleFailedState();
            break;
    }
}

void handleWaitingForMap() {
    static ros::Time last_log = ros::Time::now();
    if ((ros::Time::now() - last_log).toSec() > 2.0) {
        ROS_INFO("等待地图...");
        last_log = ros::Time::now();
    }
}

void handleWaitingForStart() {
    static ros::Time last_log = ros::Time::now();
    if ((ros::Time::now() - last_log).toSec() > 2.0) {
        ROS_INFO("等待起点... 在Rviz中使用'2D Pose Estimate'");
        last_log = ros::Time::now();
    }
}

void handleWaitingForGoal() {
    static ros::Time last_log = ros::Time::now();
    if ((ros::Time::now() - last_log).toSec() > 2.0) {
        ROS_INFO("等待目标点... 在Rviz中使用'2D Nav Goal'");
        last_log = ros::Time::now();
    }
}

void handleBothPointsSet() {
    if (!map_ready_ || !start_point_set_ || !target_point_set_) {
        return;
    }
    
    ros::Time now = ros::Time::now();
    double time_since_last_plan = (now - last_planning_time_).toSec();
    
    if (time_since_last_plan >= config_.min_replan_interval) {
        ROS_INFO("=== 开始路径规划 (导航#%d) ===", navigation_id_ + 1);
        ROS_INFO("起点: (%.3f, %.3f)", 
                 current_start_.pose.pose.position.x, 
                 current_start_.pose.pose.position.y);
        ROS_INFO("目标: (%.3f, %.3f)", 
                 current_goal_.pose.position.x, 
                 current_goal_.pose.position.y);
        
        current_state_ = PLANNING;
        last_planning_time_ = now;
        abort_current_planning_ = false;
    }
}

void executePlanning() {
    ROS_INFO("=== 执行规划 (导航#%d, 尝试#%d) ===", 
             navigation_id_ + 1, planning_attempts_ + 1);
    
    planning_attempts_++;
    
    if (!astar_planner_ || !start_point_set_ || !target_point_set_ || !map_ready_) {
        ROS_WARN("规划条件不满足");
        current_state_ = FAILED;
        return;
    }
    
    std::vector<cv::Point> path_points;
    bool success = false;
    
    auto start_time = std::chrono::high_resolution_clock::now();
    
    if (astar_planner_) {
        success = astar_planner_->pathPlanning(path_points);
    }
    
    auto end_time = std::chrono::high_resolution_clock::now();
    double planning_time = std::chrono::duration<double>(end_time - start_time).count();
    
    ROS_INFO("规划耗时: %.3f 秒", planning_time);
    
    if (abort_current_planning_) {
        ROS_INFO("规划被中止，返回BOTH_POINTS_SET状态");
        current_state_ = BOTH_POINTS_SET;
        abort_current_planning_ = false;
        return;
    }
    
    if (success && !path_points.empty()) {
        global_path_ = convertToPoseStamped(path_points);
        
        if (dwa_planner_) {
            dwa_planner_->setGlobalPlan(global_path_);
            ROS_INFO("传统DWA: 全局路径设置完成，%zu 个点", global_path_.size());
        }
        
        publishGlobalPath(global_path_);
        publishAstarPath(global_path_);
        publishMarkers();
        
        current_state_ = EXECUTING;
        navigation_counter_++;
        navigation_id_++;
        planning_attempts_ = 0;
        abort_current_planning_ = false;
        
        ROS_INFO("=== 规划成功! 导航#%d 开始 ===", navigation_id_);
    } else {
        ROS_WARN("=== 规划失败 ===");
        
        if (planning_attempts_ >= 3) {
            ROS_ERROR("达到最大规划尝试次数(%d)，进入FAILED状态", planning_attempts_);
            current_state_ = FAILED;
        } else {
            ROS_INFO("将在下一个周期重试规划");
            current_state_ = BOTH_POINTS_SET;
        }
    }
}

void executeControl() {
    if (!robot_pose_valid_) {
        publishStopCommand();
        ROS_WARN("机器人位姿无效，停止");
        return;
    }
    
    // 检查目标是否到达
    if (dwa_planner_ && dwa_planner_->isGoalReached(robot_pose_)) {
        current_state_ = GOAL_REACHED;
        publishStopCommand();
        ROS_INFO("=== 目标到达! ===");
        ROS_INFO("导航#%d 成功完成", navigation_id_);
        return;
    }
    
    // 检查是否需要重新规划
    if (config_.enable_replanning) {
        ros::Time now = ros::Time::now();
        double time_since_last_plan = (now - last_planning_time_).toSec();
        
        if (time_since_last_plan >= config_.min_replan_interval && 
            start_point_set_ && target_point_set_) {
            ROS_INFO("触发重新规划，距离上次规划 %.1f 秒", time_since_last_plan);
            current_state_ = BOTH_POINTS_SET;
            return;
        }
    }
    
    // 计算控制命令
    geometry_msgs::Twist cmd_vel;
    
    if (dwa_planner_) {
        cmd_vel = dwa_planner_->computeVelocityCommands(robot_pose_, robot_velocity_);
    } else {
        cmd_vel.linear.x = 0.0;
        cmd_vel.angular.z = 0.0;
    }
    
    // 更新局部路径
    updateLocalPath();
    
    // 发布控制命令
    if (std::isfinite(cmd_vel.linear.x) && std::isfinite(cmd_vel.angular.z)) {
        cmd_vel_pub_.publish(cmd_vel);
        
        if (use_simulated_odom_) {
            updateSimulatedOdometry(cmd_vel);
        }
    } else {
        publishStopCommand();
    }
    
    last_control_time_ = ros::Time::now();
}

void updateSimulatedOdometry(const geometry_msgs::Twist& cmd_vel) {
    static ros::Time last_update = ros::Time::now();
    ros::Time now = ros::Time::now();
    double dt = (now - last_update).toSec();
    
    if (dt > 0.0) {
        double current_yaw = quaternion_utils::getYawFromQuaternion(robot_pose_.pose.orientation);
        
        robot_pose_.pose.position.x += cmd_vel.linear.x * cos(current_yaw) * dt;
        robot_pose_.pose.position.y += cmd_vel.linear.x * sin(current_yaw) * dt;
        
        double new_yaw = current_yaw + cmd_vel.angular.z * dt;
        robot_pose_.pose.orientation = quaternion_utils::createQuaternionFromYaw(new_yaw);
        
        robot_velocity_ = cmd_vel;
        robot_pose_.header.stamp = now;
        
        last_update = now;
    }
}

void updateLocalPath() {
    if (!robot_pose_valid_ || global_path_.empty()) {
        return;
    }
    
    std::vector<geometry_msgs::PoseStamped> new_local_path;
    new_local_path.push_back(robot_pose_);
    
    int num_points = std::min(10, (int)global_path_.size());
    for (int i = 0; i < num_points; ++i) {
        new_local_path.push_back(global_path_[i]);
    }
    
    publishLocalPath(new_local_path);
}

void handleGoalReached() {
    static ros::Time last_log = ros::Time::now();
    if ((ros::Time::now() - last_log).toSec() > 1.0) {
        ROS_INFO("=== 准备新的导航 ===");
        ROS_INFO("设置新的起点和目标点以继续");
        last_log = ros::Time::now();
    }
    
    publishStopCommand();
}

void handleFailedState() {
    publishStopCommand();
    
    static ros::Time last_log = ros::Time::now();
    if ((ros::Time::now() - last_log).toSec() > 2.0) {
        ROS_WARN("导航失败! 设置新的起点和目标点以重试");
        last_log = ros::Time::now();
    }
}

std::vector<geometry_msgs::PoseStamped> convertToPoseStamped(const std::vector<cv::Point>& path_points) {
    std::vector<geometry_msgs::PoseStamped> poses;
    
    if (path_points.empty() || !map_ready_) {
        return poses;
    }
    
    for (const auto& point : path_points) {
        geometry_msgs::PoseStamped pose;
        pose.header.frame_id = "map";
        pose.header.stamp = ros::Time::now();
        
        double world_x = point.x * current_map_.info.resolution + current_map_.info.origin.position.x;
        double world_y = point.y * current_map_.info.resolution + current_map_.info.origin.position.y;
        
        pose.pose.position.x = world_x;
        pose.pose.position.y = world_y;
        pose.pose.position.z = 0.0;
        pose.pose.orientation = quaternion_utils::createQuaternionFromYaw(0.0);
        
        poses.push_back(pose);
    }
    
    return poses;
}

void publishGlobalPath(const std::vector<geometry_msgs::PoseStamped>& path) {
    if (path.empty()) {
        return;
    }
    
    nav_msgs::Path path_msg;
    path_msg.header.stamp = ros::Time::now();
    path_msg.header.frame_id = "map";
    path_msg.poses = path;
    
    global_path_pub_.publish(path_msg);
}

void publishLocalPath(const std::vector<geometry_msgs::PoseStamped>& path) {
    if (path.empty()) {
        return;
    }
    
    nav_msgs::Path path_msg;
    path_msg.header.stamp = ros::Time::now();
    path_msg.header.frame_id = "map";
    path_msg.poses = path;
    
    local_path_pub_.publish(path_msg);
}

void publishAstarPath(const std::vector<geometry_msgs::PoseStamped>& path) {
    if (path.empty()) {
        return;
    }
    
    nav_msgs::Path path_msg;
    path_msg.header.stamp = ros::Time::now();
    path_msg.header.frame_id = "map";
    path_msg.poses = path;
    
    astar_path_pub_.publish(path_msg);
}

void publishMarkers() {
    visualization_msgs::MarkerArray marker_array;
    
    // 发布起点标记
    if (start_point_set_) {
        visualization_msgs::Marker start_marker;
        start_marker.header.frame_id = "map";
        start_marker.header.stamp = ros::Time::now();
        start_marker.ns = "ab_ct_navigation";
        start_marker.id = 0;
        start_marker.type = visualization_msgs::Marker::SPHERE;
        start_marker.action = visualization_msgs::Marker::ADD;
        start_marker.pose.position.x = current_start_.pose.pose.position.x;
        start_marker.pose.position.y = current_start_.pose.pose.position.y;
        start_marker.pose.position.z = 0.1;
        start_marker.scale.x = 0.3;
        start_marker.scale.y = 0.3;
        start_marker.scale.z = 0.3;
        start_marker.color.r = 0.0;
        start_marker.color.g = 1.0;
        start_marker.color.b = 0.0;
        start_marker.color.a = 1.0;
        marker_array.markers.push_back(start_marker);
    }
    
    // 发布目标点标记
    if (target_point_set_) {
        visualization_msgs::Marker goal_marker;
        goal_marker.header.frame_id = "map";
        goal_marker.header.stamp = ros::Time::now();
        goal_marker.ns = "ab_ct_navigation";
        goal_marker.id = 1;
        goal_marker.type = visualization_msgs::Marker::SPHERE;
        goal_marker.action = visualization_msgs::Marker::ADD;
        goal_marker.pose.position.x = current_goal_.pose.position.x;
        goal_marker.pose.position.y = current_goal_.pose.position.y;
        goal_marker.pose.position.z = 0.1;
        goal_marker.scale.x = 0.3;
        goal_marker.scale.y = 0.3;
        goal_marker.scale.z = 0.3;
        goal_marker.color.r = 1.0;
        goal_marker.color.g = 0.0;
        goal_marker.color.b = 0.0;
        goal_marker.color.a = 1.0;
        marker_array.markers.push_back(goal_marker);
    }
    
    if (!marker_array.markers.empty()) {
        marker_pub_.publish(marker_array);
    }
}

void publishStopCommand() {
    geometry_msgs::Twist stop_cmd;
    stop_cmd.linear.x = 0.0;
    stop_cmd.angular.z = 0.0;
    cmd_vel_pub_.publish(stop_cmd);
}

void publishStatus() {
    static ros::Time last_publish = ros::Time::now();
    if ((ros::Time::now() - last_publish).toSec() < 1.0) {
        return;
    }
    
    last_publish = ros::Time::now();
    
    std_msgs::String status_msg;
    std::string state_str;
    
    switch (current_state_) {
        case WAITING_FOR_MAP: state_str = "等待地图"; break;
        case WAITING_FOR_START: state_str = "等待起点"; break;
        case WAITING_FOR_GOAL: state_str = "等待目标点"; break;
        case BOTH_POINTS_SET: state_str = "就绪"; break;
        case PLANNING: state_str = "规划中"; break;
        case EXECUTING: state_str = "执行中"; break;
        case GOAL_REACHED: state_str = "目标到达"; break;
        case FAILED: state_str = "失败"; break;
    }
    
    status_msg.data = state_str;
    status_pub_.publish(status_msg);
}
};  // 类定义结束

int main(int argc, char** argv) {
    ros::init(argc, argv, "ab_ctastar_dwa_navigation");
    
    try {
        ABCTAStarDWANavigation navigation_node;
        navigation_node.run();
    } catch (const std::exception& e) {
        ROS_FATAL("导航系统失败: %s", e.what());
        return 1;
    }
    
    return 0;
}